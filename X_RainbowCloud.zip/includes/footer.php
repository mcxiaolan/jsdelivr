<footer class="footer">
      <div class="container">
        <p class="text-muted">Copyright &copy; 2020 <a href="/"><?php echo $conf['title']?></a></p>
        <p class="text-muted">Power by <a href="https://pan.cccyun.cc" target="_blank">彩虹云网盘</a></p>
        <p class="text-muted">魔改：<a href="https://blog.xiaolan.ml" target="_blank">小岚的小窝</a></p>
      </div>
    </footer>
<script src="//cdn.staticfile.org/twitter-bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script src="//cdn.staticfile.org/bootstrap-material-design/0.5.10/js/material.min.js"></script>
<script src="//cdn.staticfile.org/bootstrap-material-design/0.5.10/js/ripples.min.js"></script>
<script>
  $.material.init();
</script>
</body>
</html>